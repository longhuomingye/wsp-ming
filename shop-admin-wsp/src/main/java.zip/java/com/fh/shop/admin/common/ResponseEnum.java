package com.fh.shop.admin.common;

public enum ResponseEnum {
    USERNAME_PASSWORD_IS_ERROR(1000,"用户名或密码不能为空"),
    USERNAME_ERROR(1001,"用户名不存在"),
    PASSWORD_ERROR(1002,"密码不正确"),
    USER_ERROR(1003,"当前用户已被锁定,请明天再试"),
    SUCCESS(200,"ok");

    private int code;
    private String msg;

    private ResponseEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }



    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
