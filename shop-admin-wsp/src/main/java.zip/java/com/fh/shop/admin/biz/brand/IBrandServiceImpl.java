package com.fh.shop.admin.biz.brand;

import com.fh.shop.admin.common.DataTableResult;
import com.fh.shop.admin.common.Page;
import com.fh.shop.admin.mapper.brand.IBrandMapper;
import com.fh.shop.admin.po.brand.Brand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service(value = "brandService")
public class IBrandServiceImpl implements IBrandService {
    @Autowired
    private IBrandMapper brandMapper;

    @Override
    public void add(Brand brand) {
        brandMapper.add(brand);
    }


    @Override
    public DataTableResult list(Page page) {
        //查询总条数
        Long recordsTotal = brandMapper.getRecordsTotal();
        List<Brand> list = brandMapper.list(page);
        DataTableResult dataTableResult = new DataTableResult(page.getDraw(), recordsTotal, recordsTotal, list);
        return dataTableResult;
    }

    @Override
    public void delete(Integer id) {
        brandMapper.delete(id);
    }

    @Override
    public Brand findBrand(Integer id) {
        return brandMapper.findBrand(id);
    }

    @Override
    public void update(Brand brand) {
        brandMapper.update(brand);
    }
}
