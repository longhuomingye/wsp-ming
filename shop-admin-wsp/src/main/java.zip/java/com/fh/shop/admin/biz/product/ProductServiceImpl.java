package com.fh.shop.admin.biz.product;

import com.fh.shop.admin.common.DataTableResult;
import com.fh.shop.admin.mapper.product.IProductMapper;
import com.fh.shop.admin.param.product.ProductSearchParam;
import com.fh.shop.admin.po.product.Product;
import com.fh.shop.admin.util.FileUtil;
import com.fh.shop.admin.util.SystemConstant;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service("productService")
public class ProductServiceImpl implements ProductService {
    @Autowired
    private IProductMapper productMapper;

    /**
     * 查询商品
     * @param productSearchParam
     * @return
     */
    @Override
    public DataTableResult productList(ProductSearchParam productSearchParam) {
        //查询总条数
        Long count = productMapper.findProductByCount(productSearchParam);
        //查询本页数据
        List<Product> list = productMapper.productList(productSearchParam);
        DataTableResult dataTableResult = new DataTableResult(productSearchParam.getDraw(), count, count, list);
        return dataTableResult;
    }

    /**
     * 添加商品
     * @param product
     */
    @Override
    public void add(Product product) {
        productMapper.add(product);
    }

    /**
     * 图片上传
     * @param myfile
     * @return
     */
    @Override
    public Map uploadFile(MultipartFile myfile) {
        Map map = FileUtil.addFile(myfile);
        return map;
    }

    /**
     * 删除商品
     * @param id
     */
    @Override
    public void deleteProduct(Integer id,String mainImagePath) {
        //删除ftp服务器的图片  根据图片的名称
        System.out.println(mainImagePath);
        if(StringUtils.isNotEmpty(mainImagePath)){
            FileUtil.deleteFtpFile(mainImagePath);
        }
        productMapper.deleteProduct(id);
    }

    /**
     * 回显
     * @param id
     * @return
     */
    @Override
    public Product toUpdateProduct(Integer id) {
        Product product = productMapper.toUpdateProduct(id);
        return product;
    }

    /**
     * 修改
     * @param product
     */
    @Override
    public void updateProduct(Product product) {
        productMapper.updateProduct(product);
        //修改的同时删除ftp服务器的原来的图片
        //FileUtil.deleteFtpFile(product.getMainImagePath());
    }

    @Override
    public void updateStatus(Product product) {
        if(product.getStatus()==1){
            product.setStatus(2);
        }else{
            product.setStatus(1);
        }
        productMapper.updateStatus(product);
    }

    @Override
    public List<Product> findProductList(ProductSearchParam productSearchParam) {
        return productMapper.findProductList(productSearchParam);
    }

    @Override
    public File buildWordFile(ProductSearchParam productSearchParam) {
        // 根据条件动态查询数据
        List<Product> productList = findProductList(productSearchParam);
        // 构建数据
        buildWordData(productList);
        Map map = buildWordData(productList);
        // 转换为指定的格式
        File file = FileUtil.buildWord(map, SystemConstant.PRODUCT_WORD_FILE);
        return file;
    }

    private Map buildWordData(List<Product> productList) {
        Map map = new HashMap();
        map.put("products", productList);
        return map;
    }


}
