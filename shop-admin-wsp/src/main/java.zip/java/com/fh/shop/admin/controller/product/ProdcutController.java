package com.fh.shop.admin.controller.product;

import com.fh.shop.admin.biz.product.ProductService;
import com.fh.shop.admin.common.DataTableResult;
import com.fh.shop.admin.common.ResponseEnum;
import com.fh.shop.admin.common.ServerResponse;
import com.fh.shop.admin.param.product.ProductSearchParam;
import com.fh.shop.admin.po.product.Product;
import com.fh.shop.admin.util.DateUtil;
import com.fh.shop.admin.util.FileUtil;
import com.fh.shop.admin.util.SystemConstant;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/product")
public class ProdcutController {
    @Resource(name="productService")
    private ProductService productService;
    @Autowired
    private HttpServletRequest request;
    /**
     * 跳转查询商品页面
     * @return
     */
    @RequestMapping("/toList")
    public String toList(){
        return "/product/productList";
    }
    @Autowired
    private static final Logger LOGGER = LoggerFactory.getLogger(ProdcutController.class);

    /**
     * 查询商品
     * @return
     */
    @RequestMapping("/productList")
    @ResponseBody
    public DataTableResult productList(ProductSearchParam productSearchParam){
        DataTableResult dataTableResult = productService.productList(productSearchParam);
        return dataTableResult;
    }

    /**
     * 添加商品
     * @return
     */
    @RequestMapping("/add")
    @ResponseBody
    public ServerResponse add(Product product){
        productService.add(product);
        LOGGER.info("访问com.fh.shop.admin.controller.product.ProdcutController层添加商品成功");
        return ServerResponse.success(ResponseEnum.SUCCESS);
    }

    /**
     * 图片上传
     * @return
     */
    @RequestMapping("/uploadFile")
    @ResponseBody
    public Map uploadFile(MultipartFile myfile){
        Map map = productService.uploadFile(myfile);
        return map;
    }

    /**
     * 删除商品
     * @param id
     * @param mainImagePath
     * @return
     */
    @RequestMapping("/deleteProduct")
    @ResponseBody
    public ServerResponse deleteProduct(Integer id,String mainImagePath){
        productService.deleteProduct(id,mainImagePath);
        LOGGER.info("访问com.fh.shop.admin.controller.product.ProdcutController层删除单个商品成功");
        return ServerResponse.success(ResponseEnum.SUCCESS);
    }

    /**
     * 回显
     * @param id
     * @return
     */
    @RequestMapping("/toUpdateProduct")
    @ResponseBody
    public ServerResponse toUpdateProduct(Integer id){
        Product product = productService.toUpdateProduct(id);
        return ServerResponse.success(ResponseEnum.SUCCESS,product);
    }

    /**
     * 修改
     * @return
     */
    @RequestMapping("/updateProduct")
    @ResponseBody
    public ServerResponse updateProduct(Product product){
        productService.updateProduct(product);
        LOGGER.info("访问com.fh.shop.admin.controller.product.ProdcutController层修改商品成功");
        return ServerResponse.success(ResponseEnum.SUCCESS);
    }

    /**
     * 上架 下架
     * @param product
     * @return
     */
    @RequestMapping("/updateStatus")
    @ResponseBody
    public ServerResponse updateStatus(Product product){
        productService.updateStatus(product);
        return ServerResponse.success(ResponseEnum.SUCCESS);
    }

    /**
     * 导出excel
     * @param productSearchParam
     */
    @RequestMapping("/exportExcel")
    public void exportExcel(ProductSearchParam productSearchParam, HttpServletResponse response){
        //根据条件查询数据
        List<Product> list = productService.findProductList(productSearchParam);
        //转换为workbook
        XSSFWorkbook xsf = buildWorkBook(list);
        //下载
        FileUtil.excelDownload(xsf, response);
    }

    private XSSFWorkbook buildWorkBook(List<Product> list ) {
        XSSFWorkbook xsf = new XSSFWorkbook();
        //创建一个sheet
        XSSFSheet sheet = xsf.createSheet();
        //创建标题
        buildTitle(sheet,xsf);
        // 创建第一行  构造表头
        buildHeadRow(sheet);
        //将查询到的数据输入到文档中
        buildBody(list, sheet);
        System.out.println();
        return xsf;
    }

    private void buildTitle(XSSFSheet sheet,XSSFWorkbook xsf) {
        XSSFCellStyle cellStyle = buildTitleStyle(xsf);
        XSSFRow row = sheet.createRow(3);
        XSSFCell cell = row.createCell(7);
        cell.setCellValue("商品列表");
        //第四行到第六行   第8个单元格到第10个单元格
        CellRangeAddress cellRangeAddress = new CellRangeAddress(3, 5, 7, 9);
        sheet.addMergedRegion(cellRangeAddress);
        cell.setCellStyle(cellStyle);
    }

    private XSSFCellStyle buildTitleStyle(XSSFWorkbook xsf) {
        XSSFCellStyle cellStyle = xsf.createCellStyle();
        //水平居中
        cellStyle.setAlignment(CellStyle.ALIGN_CENTER);
        //垂直居中
        cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        return cellStyle;
    }

    private void buildHeadRow(XSSFSheet sheet) {
        //表头
        String[] head = {"商品名称", "价格"};
        XSSFRow row = sheet.createRow(6);
        for (int i = 0; i < head.length; i++) {
            row.createCell(i+7).setCellValue(head[i]);
        }
    }

    private void buildBody(List<Product> list, XSSFSheet sheet) {
        for (int i = 0; i < list.size(); i++) {
            //从第二行开始创建
            XSSFRow rowTo = sheet.createRow(i + 7);
            rowTo.createCell(7).setCellValue(list.get(i).getProductName());
            rowTo.createCell(8).setCellValue(list.get(i).getPrice());
        }
    }

    /**
     * 导出pdf
     * @param productSearchParam
     */
    @RequestMapping("/exportPdf")
    private void exportPdf(ProductSearchParam productSearchParam,HttpServletResponse response){
        //根据条件查询数据
        List<Product> list = productService.findProductList(productSearchParam);
        // 构建模板数据
        Map data = buildData(list);
        // 生成模板对应的html
        String htmlContent = FileUtil.buildPdfHtml(data, SystemConstant.PRODUCT_PDF_TEMPLATE_FILE);
        // 转为pdf并进行下载
        FileUtil.pdfDownloadFile(response, htmlContent);
    }


    private Map buildData(List<Product> productList) {
        Map data = new HashMap();
        //单位
        data.put("companyName", SystemConstant.COMPANY_NAME);
        //数据
        data.put("products", productList);
        //导出的时间
        data.put("createDate", DateUtil.date2str(new Date(), DateUtil.Y_M_D));
        return data;
    }

    /**
     * 导出word
     * @param productSearchParam
     * @param response
     */
    @RequestMapping(value = "/exportWord")
    public void exportWord(ProductSearchParam productSearchParam, HttpServletResponse response){
        File file = productService.buildWordFile(productSearchParam);
        // 调用下载方法
        FileUtil.downloadFile(request,response,file.getPath(),file.getName());
        //删除垃圾文件
        file.delete();
    }
}
