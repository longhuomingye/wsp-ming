package com.fh.shop.admin.interceptor;

import com.fh.shop.admin.po.user.User;
import com.fh.shop.admin.util.SystemConstant;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginInterceptor extends HandlerInterceptorAdapter {

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        System.out.println("这里是拦截器");
        User user = (User) request.getSession().getAttribute(SystemConstant.USER);
        //获取当前请求的路径
        //String requestURI = request.getRequestURI();
        if(user!=null){
            /*//如果当前请求是欢迎界面跳转 继续执行
            if(SystemConstant.GREET.equals(requestURI)){
                return true;
            }
            //从session中取出当前用户的所有资源
            List<WealthVo> wealthList = (List<WealthVo>) request.getSession().getAttribute(SystemConstant.LISTURL);
            for (WealthVo wealth : wealthList) {
                if(StringUtils.isNotEmpty(wealth.getUrl())){
                    //判断当前用户是否持有当前请求对应的资源
                    if(requestURI.contains(wealth.getUrl())){
                        return true;
                    }
                }
            }
            //如果没有当前请求 重定向到错误界面
            response.sendRedirect(SystemConstant.ERRORJSP);
            return false;*/
            return true;
        }else{
            response.sendRedirect("/");
            return false;
        }
    }
}
