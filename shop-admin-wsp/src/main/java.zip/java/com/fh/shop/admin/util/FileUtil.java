package com.fh.shop.admin.util;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;
import com.itextpdf.tool.xml.XMLWorkerFontProvider;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import com.itextpdf.tool.xml.XMLWorkerHelper;

public class FileUtil {

    public static FTPClient ftp = null;

    /**
     * 连接ftp服务器
     */
    public static void initFtpClient() {
        ftp = new FTPClient();
        try {
            //设置ftp服务器ip地址
            ftp.connect(GlobalInter.IP_FTP);
            //登录
            ftp.login(GlobalInter.FTP_USERNAME, GlobalInter.FTP_USERPWD);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 上传图片到ftp服务器
     *
     * @param uuid
     * @param inputStream
     */
    public static void uploadFile(String uuid, InputStream inputStream) {
        initFtpClient();
        try {
            //切换到指定目录
            ftp.changeWorkingDirectory(GlobalInter.FTP_PATH);
            //设置上传文件的类型
            ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
            //上传
            ftp.storeFile(uuid, inputStream);
            System.out.println("上传ftp");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                //退出连接
                ftp.logout();
                //关闭连接
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 图片上传
     *
     * @param myfile
     * @return
     */
    public static Map addFile(MultipartFile myfile) {
        Map map = new HashMap();
        if (myfile != null) {
            //图片原名称
            String originalFilename = myfile.getOriginalFilename();
            //上传后的图片名称
            String uuid = UUID.randomUUID().toString() + originalFilename.substring(originalFilename.lastIndexOf("."));
            //图片流文件
            try {
                InputStream inputStream = myfile.getInputStream();
                FileUtil.uploadFile(uuid, inputStream);
                map.put("url", uuid);
                System.out.println("上传成功");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return map;
    }

    /**
     * 删除ftp服务器上的图片
     *
     * @param mainImagePath
     */
    public static void deleteFtpFile(String mainImagePath) {
        //连接服务器
        initFtpClient();
        try {
            //切换到指定的目录下
            ftp.changeWorkingDirectory(GlobalInter.FTP_PATH);
            //通过图片名称来删除图片
            ftp.dele(mainImagePath);
            System.out.println("删除成功");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                //退出登录  会自动断开连接  也就是 自动调用 disconnect方法
                ftp.logout();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 下载ptf文件
     *
     * @param response
     * @param byffer
     */
    public static void pdfDownload(HttpServletResponse response, ByteArrayOutputStream byffer) {

        // inline在浏览器中直接显示，不提示用户下载
        // attachment弹出对话框，提示用户进行下载保存本地
        // 默认为inline方式
        response.setHeader("Content-Disposition", "attachment; filename=" + UUID.randomUUID().toString() + ".pdf");
        // 不同类型的文件对应不同的MIME类型
        response.setContentType("application/octet-stream;charset=UTF-8");
        ServletOutputStream out;
        try {
            //获取输出流
            out = response.getOutputStream();
            //调用方法下载
            byffer.writeTo(out);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 设置ptf标题
     *
     * @param value
     * @param font
     * @return
     */
    public static PdfPCell createHeadline(String value, Font font) {
        // 创建一个单元格
        PdfPCell cell = new PdfPCell();
        // new Paragraph()是段落的处理，可以设置段落的对齐方式，缩进和间距。
        cell.setPhrase(new Paragraph(value, font));
        //设置单元格的水平对齐方式
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        // 设置单元格的垂直对齐方式
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setMinimumHeight(30);//设置表格行高
        cell.setBorderWidth(0f);//去除表格的边框
        cell.setColspan(19);//跨列
        return cell;
    }

    /**
     * 创建单元格 ptf
     *
     * @param value
     * @param font
     * @param align
     * @return
     */
    public static PdfPCell createCell(String value, Font font, int align) {
        // 创建一个单元格
        PdfPCell cell = new PdfPCell();
        // 设置单元格的垂直对齐方式
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        // 设置单元格的水平对齐方式
        cell.setHorizontalAlignment(align);
        cell.setPhrase(new Phrase(value, font));
        return cell;
    }

    /**
     * 创建表格
     *
     * @param colNumber
     * @return
     */
    public static PdfPTable createTable(int colNumber) {
        // 创建表格
        PdfPTable table = new PdfPTable(colNumber);
        // 设置表格的总宽度
        table.setTotalWidth(SystemConstant.MAXWidth);
        //锁定宽度
        table.setLockedWidth(true);
        // 设置表格的垂直对齐方式
        table.setHorizontalAlignment(Element.ALIGN_CENTER);
        // 设置边框
        table.getDefaultCell().setBorder(1);
        return table;
    }

    /**
     * 内容字体
     *
     * @return
     * @throws IOException
     * @throws DocumentException
     */
    public static Font keyFont() throws IOException, DocumentException {
        // 设置为中文 STSong-Light是宋体 不嵌入
        BaseFont createFont = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
        //设置内容的字体样式
        Font keyfont = new Font(createFont, 10, Font.BOLD);
        return keyfont;
    }

    /**
     * 标题字体
     *
     * @return
     * @throws IOException
     * @throws DocumentException
     */
    public static Font headFont() throws IOException, DocumentException {
        // 设置为中文 STSong-Light是宋体 不嵌入
        BaseFont createFont = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
        // 标题字体
        Font headfont = new Font(createFont, 25, Font.BOLD);
        return headfont;
    }

    /**
     * 导出excel
     *
     * @param wirthExcelWB
     * @param response
     */
    public static void excelDownload(XSSFWorkbook wirthExcelWB, HttpServletResponse response) {
        OutputStream out = null;
        try {
            out = response.getOutputStream();
            // 让浏览器识别是什么类型的文件
            response.reset(); // 重点突出
            response.setCharacterEncoding("UTF-8"); // 重点突出
            response.setContentType("application/x-msdownload");// 不同类型的文件对应不同的MIME类型
            // // 重点突出
            // inline在浏览器中直接显示，不提示用户下载
            // attachment弹出对话框，提示用户进行下载保存本地
            // 默认为inline方式
            response.setHeader("Content-Disposition", "attachment;filename=" + UUID.randomUUID().toString() + ".xlsx");
            wirthExcelWB.write(out);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (null != out) {
                try {
                    out.close();
                    out = null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void wordDownload(Map map, HttpServletRequest request, HttpServletResponse response) throws IOException, TemplateException {
        // 新建配置对象
        Configuration configuration = new Configuration();
        // 设置默认编码
        configuration.setDefaultEncoding("UTF-8");
        // 设置模板所在路径
        configuration.setClassForTemplateLoading(FileUtil.class, "/template");
        // 获取模板对象
        Template t = configuration.getTemplate("test.xml", "UTF-8");
        // 创建文件对象
        File file = new File("D:/" + UUID.randomUUID().toString() + ".docx");
        // 新建文件输出流
        FileOutputStream fos = new FileOutputStream(file);
        // 新建写入器
        OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
        // 把数据写入文件里
        t.process(map, osw);
        //刷新缓冲区
        osw.flush();
        //关流
        osw.close();
        FileUtil.downloadFile(request, response, file.getPath(), file.getName());
        // 删除没用的文件
        file.delete();
    }

    /**
     * 下载
     *
     * @param request
     * @param response
     * @param downloadFile
     * @param fileName
     */
    public static void downloadFile(HttpServletRequest request, HttpServletResponse response, String downloadFile,
                                    String fileName) {
        BufferedInputStream bis = null;
        InputStream is = null;
        OutputStream os = null;
        BufferedOutputStream bos = null;
        try {
            File file = new File(downloadFile);
            is = new FileInputStream(file); // 文件流的声明
            os = response.getOutputStream(); // 重点突出(特别注意),通过response获取的输出流，作为服务端向客户端浏览器输出内容的通道
            // 为了提高效率使用缓冲区流
            bis = new BufferedInputStream(is);
            bos = new BufferedOutputStream(os);
            // 处理下载文件名的乱码问题(根据浏览器的不同进行处理)
            if (request.getHeader("User-Agent").toLowerCase().indexOf("firefox") > 0) {
                fileName = new String(fileName.getBytes("GB2312"), "ISO-8859-1");
            } else {
                // 对文件名进行编码处理中文问题
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");// 处理中文文件名的问题
                fileName = new String(fileName.getBytes("UTF-8"), "GBK");// 处理中文文件名的问题
            }
            response.reset(); // 重点突出
            response.setCharacterEncoding("UTF-8"); // 重点突出
            response.setContentType("application/x-msdownload");// 不同类型的文件对应不同的MIME类型
            // // 重点突出
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName);// 重点突出
            int bytesRead = 0;
            byte[] buffer = new byte[4096];
            while ((bytesRead = bis.read(buffer)) != -1) { // 重点
                bos.write(buffer, 0, bytesRead);// 将文件发送到客户端
                bos.flush();
            }

        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        } finally {
            // 特别重要
            // 1. 进行关闭是为了释放资源
            // 2. 进行关闭会自动执行flush方法清空缓冲区内容
            try {
                if (null != bis) {
                    bis.close();
                    bis = null;
                }
                if (null != bos) {
                    bos.close();
                    bos = null;
                }
                if (null != is) {
                    is.close();
                    is = null;
                }
                if (null != os) {
                    os.close();
                    os = null;
                }
            } catch (Exception ex) {
                throw new RuntimeException(ex.getMessage());
            }
        }
    }

    /**
     * 从ftp服务器下载图片
     * @param str
     */
    public static void ftpDownload(String str){
        try {
            //连接数据库
            initFtpClient();
            //切换目录到图片所在目录
            ftp.changeWorkingDirectory(GlobalInter.FTP_PATH);
            //获取当前目录下的所有文件
            FTPFile[] listFiles = ftp.listFiles();
            for (FTPFile file : listFiles) {
                //这个方法和equals一样 只是  这个方法 忽略大小写
                if(str.equalsIgnoreCase(file.getName())){
                    //指定一个下载本地路径，然后给一个文件名称
                    FileOutputStream out = new FileOutputStream(new File("D:/upload/"+file.getName()));
                    //从服务器查找指定的文件然后写入指定的OutputStream中如果成功完成返回True,否则为false
                    ftp.retrieveFile(file.getName(), out);
                    out.close();
                    ftp.logout();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 把数据转换为html
     * @param data
     * @param pdfTemplateFile
     * @return
     */
    public static String buildPdfHtml(Map data, String pdfTemplateFile){
        // 将其转换为html
        StringWriter sw = null;
        try {
            Configuration configuration = new Configuration();
            // 解决freemarker的乱码问题
            configuration.setDefaultEncoding("utf-8");
            //指定模板文件所属文件夹
            configuration.setClassForTemplateLoading(FileUtil.class, SystemConstant.TEMPLATE_PATH);
            //指定模板文件
            Template template = configuration.getTemplate(pdfTemplateFile);
            sw = new StringWriter();
            template.process(data, sw);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } catch (TemplateException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        return sw.toString();
    }

    /**
     * 下载pdf文件
     * @param response
     * @param htmlContent
     */
    public static void pdfDownloadFile(HttpServletResponse response, String htmlContent) {
        OutputStream os = null;
        com.itextpdf.text.Document document = null;
        PdfWriter writer = null;
        try {
            os = response.getOutputStream(); //重点突出(特别注意),通过response获取的输出流，作为服务端向客户端浏览器输出内容的通道
            // 处理下载文件名的乱码问题(根据浏览器的不同进行处理)
            response.reset(); // 重点突出
            response.setCharacterEncoding("UTF-8"); // 重点突出
            response.setContentType("application/x-msdownload");// 不同类型的文件对应不同的MIME类型 // 重点突出
            response.setHeader("Content-Disposition", "attachment;filename="+ UUID.randomUUID().toString()+".pdf");// 重点突出
            // step 1
            document = new com.itextpdf.text.Document();
            // step 2
            writer = PdfWriter.getInstance(document, os);
            // step 3
            document.open();
            // step 4
            XMLWorkerFontProvider fontImp = new XMLWorkerFontProvider(XMLWorkerFontProvider.DONTLOOKFORFONTS);
            fontImp.register("simhei.ttf");
            XMLWorkerHelper.getInstance().parseXHtml(writer, document,
                    new ByteArrayInputStream(htmlContent.getBytes("utf-8")), null, Charset.forName("UTF-8"), fontImp);
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        } finally {
            // 特别重要
            // 1. 进行关闭是为了释放资源
            // 2. 进行关闭会自动执行flush方法清空缓冲区内容
            if (null != document) {
                document.close();
                document = null;
            }
            if (null != writer) {
                writer.close();
                writer = null;
            }
            if (null != os) {
                try {
                    os.close();
                    os = null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 构造word文件
     * @param data
     * @param templateFile
     * @return
     */
    public static File buildWord(Map data, String templateFile){
        FileOutputStream out = null;
        OutputStreamWriter osw = null;
        File file = null;
        try {
            Configuration configuration = new Configuration();
            //制定模板的路径
            configuration.setClassForTemplateLoading(FileUtil.class, SystemConstant.TEMPLATE_PATH);
            //设置编码
            configuration.setDefaultEncoding("utf-8");
            //指定模板文件夹下的具体模板文件
            Template template = configuration.getTemplate(templateFile);
            file = new File(SystemConstant.WORD_SAVE_PATH+UUID.randomUUID().toString()+SystemConstant.WORD_SUFFIX);
            out = new FileOutputStream(file);
            osw = new OutputStreamWriter(out, "utf-8");
            template.process(data, osw);
            osw.flush();
        } catch (TemplateException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } finally {
            if (null != osw) {
                try {
                    osw.close();
                    osw = null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null != out) {
                try {
                    out.close();
                    out = null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return file;
    }
}
