package com.fh.shop.admin.controller.user;

import com.fh.shop.admin.biz.user.IUserService;
import com.fh.shop.admin.biz.wealth.IWealthService;
import com.fh.shop.admin.common.DataTableResult;
import com.fh.shop.admin.common.ResponseEnum;
import com.fh.shop.admin.common.ServerResponse;
import com.fh.shop.admin.param.UserSearchParam;
import com.fh.shop.admin.po.user.User;
import com.fh.shop.admin.po.wealth.Wealth;
import com.fh.shop.admin.util.DateUtil;
import com.fh.shop.admin.util.FileUtil;
import com.fh.shop.admin.util.Md5Util;
import com.fh.shop.admin.util.SystemConstant;
import com.fh.shop.admin.vo.user.UserVo;
import com.fh.shop.admin.vo.wealth.WealthVo;
import com.itextpdf.text.DocumentException;
import freemarker.template.TemplateException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/user")
@Component
public class UserController {
    @Resource(name = "userService")
    private IUserService userService;
    @Autowired
    HttpServletRequest request;
    @Resource(name = "wealthService")
    private IWealthService wealthService;
    @Autowired
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    /**
     * 这是新增用户的方法
     *
     * @return
     */
    @RequestMapping(value = "/add", produces = "application/json;charset=UTF-8")
    @ResponseBody
    public ServerResponse add(User user) {
        userService.addUser(user);
        LOGGER.info("访问com.fh.shop.admin.controller.user.UserController层新增用户方法成功");
        return ServerResponse.success(ResponseEnum.SUCCESS);
    }

    /**
     * 查询用户表的所有数据/条件查询(查询条件)
     *
     * @return
     */
    @ResponseBody
    @RequestMapping("/userList")
    public DataTableResult userList(UserSearchParam userSearchParam) {
        DataTableResult dataTableResult = userService.userList(userSearchParam);
        return dataTableResult;
    }

    /**
     * 这是跳转查询页面的方法
     *
     * @return
     */
    @RequestMapping("/toList")
    public String toUserList() {
        return "/user/userList";
    }

    /**
     * 回显
     *
     * @return
     */
    @RequestMapping(value = "/toUpdateUser", produces = "application/json;charset=UTF-8")
    @ResponseBody
    public ServerResponse toUpdateUser(Integer id) {
        UserVo user = null;
        user = userService.toUpdateUser(id);
        return ServerResponse.success(ResponseEnum.SUCCESS, user);
    }

    /**
     * 这是修改用户资料的方法
     *
     * @return
     */
    @RequestMapping(value = "/updateUser", produces = "application/json;charset=UTF-8")
    @ResponseBody
    public ServerResponse updateUser(User user) {
        userService.updateUser(user);
        LOGGER.info("访问com.fh.shop.admin.controller.user.UserController层修改用户方法成功");
        return ServerResponse.success(ResponseEnum.SUCCESS);
    }

    /**
     * 删除单条数据的方法
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "deleteUser", produces = "application/json;charset=UTF-8")
    @ResponseBody
    public ServerResponse deleteUser(Integer id) {
        userService.deleteUser(id);
        LOGGER.info("访问com.fh.shop.admin.controller.user.UserController层删除单个用户方法成功");
        return ServerResponse.success(ResponseEnum.SUCCESS);

    }

    /**
     * 批量删除
     *
     * @param ids
     * @return
     */
    @RequestMapping("/deleteUserByIds")
    @ResponseBody
    public ServerResponse deleteUserByIds(Integer[] ids) {
        userService.deleteUserByIds(ids);
        LOGGER.info("访问com.fh.shop.admin.controller.user.UserController层批量删除用户方法成功");
        return ServerResponse.success(ResponseEnum.SUCCESS);
    }

    /**
     * 图片上传
     *
     * @return
     */
    @RequestMapping("/uploadFile")
    @ResponseBody
    public Map uploadFile(MultipartFile myfile) {
        Map map = userService.uploadFile(myfile);
        return map;
    }


    public User userTimt = new User();

    /**
     * 登录验证
     *
     * @param user
     * @return
     */
    @RequestMapping("/login")
    @ResponseBody
    public ServerResponse login(User user) {
        //根据用户名查询对象
        User userInfo = userService.login(user);
        //userTimt = userInfo;
        //验证用户名或密码是否为空
        if (!StringUtils.isNotEmpty(user.getUserName()) || !StringUtils.isNotEmpty(user.getPassword())) {
            return ServerResponse.error(ResponseEnum.USERNAME_PASSWORD_IS_ERROR);
        }
        //验证用户名是否存在
        if (userInfo == null) {
            return ServerResponse.error(ResponseEnum.USERNAME_ERROR);
        }
        //判断当前账户是否锁定
        if (userInfo.getLockState() == 1) {
            return ServerResponse.error(ResponseEnum.USER_ERROR);
        }
        //验证密码是否正确
        String s = Md5Util.md5(Md5Util.md5(user.getPassword())+userInfo.getSalt());
        if (!userInfo.getPassword().equals(s)) {
            //判断当前账户的连续登陆次数是否为null 如果是 设置为0
            if (userInfo.getLoginCount() == null) {
                userInfo.setLoginCount(0);
            }
            //密码错误  连续登陆次数+1
            userInfo.setLoginCount(userInfo.getLoginCount() + 1);
            System.out.println(userInfo.getLoginCount() + "失败");
            //连续登陆错误次数大于等于3次 锁定当前用户
            if (userInfo.getLoginCount() >= 3) {
                userInfo.setLockState(1);
            }
            //修改连续登陆次数
            userService.updateUserLoginCount(userInfo);
            return ServerResponse.error(ResponseEnum.PASSWORD_ERROR);
        } else {
            userInfo.setLoginCount(0);
            //密码正确  清空连续登陆次数
            userService.updateUserLoginCount(userInfo);
            System.out.println(userInfo.getLoginCount() + "成");
        }
        //获取当天时间
        String today = DateUtil.date2str(new Date(), DateUtil.Y_M_D);
        //获取当前用户的上次登录时间  转换成字符串  同时工具类里做了非空判断
        String newDate = DateUtil.date2str(userInfo.getLoginTime(), DateUtil.Y_M_D);
        //登录成功 保存当天登录次数
        if (!today.equals(newDate)) {
            //如果是今天第一次登录  保存为1
            userInfo.setCount(1);
        } else {
            //如果是当天登录 在原有基础上+1
            userInfo.setCount(userInfo.getCount() + 1);
        }
        //登录成功 把当前登录的用户放入session中
        request.getSession().setAttribute(SystemConstant.USER, userInfo);
        //把用户对应的资源放入session中
        List<WealthVo> wealthVoList = wealthService.findWealthByUserId();
        request.getSession().setAttribute(SystemConstant.MANU_USER,wealthVoList);
        //把所有的资源放入session
        List<Wealth> wealthListUrl = wealthService.findWealthUrl();
        request.getSession().setAttribute(SystemConstant.MANULIST,wealthListUrl);
        //更新数据
        userService.updateUserTime(userInfo);
        return ServerResponse.success(ResponseEnum.SUCCESS);
    }

    /**
     * 退出登录
     *
     * @return
     */
    @RequestMapping("/logout")
    public String logout() {
        request.getSession().invalidate();
        return "redirect:/";
    }

    /**
     * 定时器
     */
    @Scheduled(cron = "0 0 0 * * ?")//秒、分、时、日、月、周、年（可选）
    public void time() {
        System.out.println("进了");
        updateTime();
    }

    /**
     * 定时解锁同时刷新连续登陆失败次数
     */
    public void updateTime() {
        userTimt.setLoginCount(0);
        userTimt.setLockState(2);
        userService.updateUserLoginCount(userTimt);
        System.out.println("=========================");
    }

    /**
     * 导出pdf
     *
     * @param userSearchParam
     */
    @RequestMapping("/exportPdf")
    public void exportPdf(UserSearchParam userSearchParam, HttpServletResponse response) throws IOException, DocumentException {
        userService.exportPdf(userSearchParam,response);
    }

    /**
     * 导出excel
     *
     * @param userSearchParam
     * @param response
     */
    @RequestMapping("/exportExcel")
    public void exportExcel(UserSearchParam userSearchParam, HttpServletResponse response) {
        userService.exportExcel(userSearchParam,response);
    }

    /**
     * 导出word
     */
    @RequestMapping("/exportWord")
    public void exportWord(UserSearchParam userSearchParam,HttpServletResponse response) throws IOException, TemplateException {
        if(userSearchParam.getRoleIds()!=null){
            userSearchParam.setRoleIdsLengTh(userSearchParam.getRoleIds().length);
        }
        //条件查询数据源
        List<UserVo> userList = userService.findUser(userSearchParam);
        //处理性别
        for (UserVo userVo : userList) {
            userVo.setSexNmae((userVo.getSex() == 1 ? "男" : userVo.getSex() == 0 ? "女" : "未知"));
        }
        Map map = new HashMap();
        map.put("list",userList);
        //调用下载
        FileUtil.wordDownload(map,request,response);
    }

    /**
     * 验证当前用户名是否重复
     * @return
     */
    @RequestMapping("/loginUserName")
    @ResponseBody
    public Map loginUserName(User user){
        Map map = new HashMap();
        User login = userService.login(user);
        if(null!=login){
            map.put("valid",false);
        }else{
            map.put("valid",true);
        }
        return map;
    }
}
