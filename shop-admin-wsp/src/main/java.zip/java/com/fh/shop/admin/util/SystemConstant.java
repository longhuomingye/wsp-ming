package com.fh.shop.admin.util;

public final class SystemConstant {
    public static String USER = "user";
    static int MAXWidth = 520;// 总宽度
    public static String GREET = "/index/indexJsp.jhtml";//欢迎界面路径
    public static String MANULIST = "wealthListUrl";//当前用户持有的资源的key
    public static String ERRORJSP = "/error.jsp";//错误界面
    public static String MANU_USER="wealthList";//用户对应的资源
    public static final String COMPANY_NAME = "1902";//导出pdf文件的单位
    public static final String TEMPLATE_PATH = "/template";//模板所属文件夹
    public static final String PRODUCT_PDF_TEMPLATE_FILE = "info.html";//制定pdf模板html
    public static final String PRODUCT_WORD_FILE="product-template.xml";//导出word模板文件
    public static final String WORD_SAVE_PATH = "d:/upload/";//存放文件的路径
    public static final String WORD_SUFFIX = ".docx";//word文件后缀
}
