package com.fh.shop.admin.controller.brand;

import com.fh.shop.admin.biz.brand.IBrandService;
import com.fh.shop.admin.common.DataTableResult;
import com.fh.shop.admin.common.Page;
import com.fh.shop.admin.common.ResponseEnum;
import com.fh.shop.admin.common.ServerResponse;
import com.fh.shop.admin.po.brand.Brand;
import com.fh.shop.admin.util.FileUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.Map;

@Controller
@RequestMapping(value = "/brand")
public class BrandController {
    @Resource(name = "brandService")
    private IBrandService brandService;
    @Autowired
    private static final Logger LOGGER = LoggerFactory.getLogger(BrandController.class);

    /**
     * ajax添加
     * @param brand
     * @return
     */
    @RequestMapping(value = "/addAjax")
    @ResponseBody
    public ServerResponse addAjax(Brand brand){
        brandService.add(brand);
        LOGGER.info("访问com.fh.shop.admin.controller.brand.BrandController层新增品牌方法成功");
        return ServerResponse.success(ResponseEnum.SUCCESS);
    }

    /**
     * 去列表展示页面
     * @return
     */
    @RequestMapping(value = "/toList")
    public String toList(){
        return "brand/list";
    }

    /**
     * 查询list数据
     * @return
     */
    @RequestMapping(value = "/list")
    @ResponseBody
    public DataTableResult list(Page page){
        DataTableResult dataTableResult = brandService.list(page);
        return dataTableResult;
    }

    /**
     * 删除
     * @param id
     * @return
     */
    @RequestMapping(value = "delete")
    @ResponseBody
    public ServerResponse delete(Integer id){
        brandService.delete(id);
        LOGGER.info("访问com.fh.shop.admin.controller.brand.BrandController层删除单个品牌方法成功");
        return ServerResponse.success(ResponseEnum.SUCCESS);
    }

    /**
     * 回显
     * @param id
     * @return
     */
    @RequestMapping(value = "findBrand")
    @ResponseBody
    public ServerResponse findBrand(Integer id){
        Brand brand = brandService.findBrand(id);
        return ServerResponse.success(ResponseEnum.SUCCESS,brand);
    }

    /**
     * ajax修改
     * @param brand
     * @return
     */
    @RequestMapping(value = "updateAjax")
    @ResponseBody
    public ServerResponse updateAjax(Brand brand){
        brandService.update(brand);
        LOGGER.info("访问com.fh.shop.admin.controller.brand.BrandController层修改品牌方法成功");
        return ServerResponse.success(ResponseEnum.SUCCESS,brand);
    }

    /**
     * 图片上传
     * @param myfile
     * @return
     */
    @RequestMapping("/uploadFile")
    @ResponseBody
    public Map uploadFile(MultipartFile myfile){
        Map map = FileUtil.addFile(myfile);
        return map;
    }
}
