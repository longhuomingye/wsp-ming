package com.fh.shop.admin.biz.user;

import com.fh.shop.admin.common.DataTableResult;
import com.fh.shop.admin.mapper.user.IUserMapper;
import com.fh.shop.admin.mapper.wealth.IWealthMapper;
import com.fh.shop.admin.param.UserSearchParam;
import com.fh.shop.admin.po.user.User;
import com.fh.shop.admin.po.wealth.Wealth;
import com.fh.shop.admin.util.DateUtil;
import com.fh.shop.admin.util.FileUtil;
import com.fh.shop.admin.util.Md5Util;
import com.fh.shop.admin.vo.user.UserVo;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.List;

@Service("userService")
public class IUserServiceImpl implements IUserService {
    @Autowired
    private IUserMapper userMapper;
    @Autowired
    private IWealthMapper wealthMapper;
    /**
     * 这是新增用户的方法
     * @param user
     */
    @Override
    public void addUser(User user) {
        //生成salt
        String salt = UUID.randomUUID().toString();
        user.setSalt(salt);
        //双重md5加密
        user.setPassword(Md5Util.md5(Md5Util.md5(user.getPassword())+salt));
        userMapper.addUser(user);
        //添加角色到用户角色中间表
        Integer[] roleIds = user.getRoleIds();
        if(roleIds!=null && roleIds.length>0){
            addUserRoleById(user, roleIds);
        }
    }

    private void addUserRoleById(User user, Integer[] roleIds) {
        List<Map> list = new ArrayList<>();
        for (int i =0;i<roleIds.length;i++){
            Map map = new HashMap();
            map.put("roleId",roleIds[i]);
            map.put("userId",user.getId());
            list.add(map);
            System.out.println(1);
        }
        userMapper.addUserOnRole(list);
    }

    /**
     * 查询数据库中的所有用户信息/条件查询
     * @return
     */
    @Override
    public DataTableResult userList(UserSearchParam userSearchParam) {
        //查询总条数
        Long count = userMapper.findUserByCount(userSearchParam);
        //查询当前页的数据
        System.out.println(1);
        List<User> userList = userMapper.userList(userSearchParam);
        //po转换vo用于展示
        List<UserVo> userVoList = buildUserVo(userList);
        DataTableResult dataTableResult = new DataTableResult(userSearchParam.getDraw(),count,count,userVoList);
        return dataTableResult;
    }

    private List<UserVo> buildUserVo(List<User> userList) {
        List<UserVo> userVoList = new ArrayList<>();
        for (User userInfo : userList) {
            UserVo userVo = getUserVo(userInfo);
            //查询每个用户的所有角色名称集合
            System.out.println(1);
            List<String> roleNameList = userMapper.roleListById(userInfo.getId());
            //分割 拼接 拿到最后的展示用字符串
            if(roleNameList!=null && roleNameList.size()>0){
                //把集合里的数据用指定的分隔符给拼接成字符串
                String join = StringUtils.join(roleNameList, ",");
                //赋值给展示用的vo实体类对象
                userVo.setRoleNames(join);
            }else{
                userVo.setRoleNames("无角色");
            }
            //每次赋值完毕添加到集合里
            userVoList.add(userVo);
        }
        return userVoList;
    }

    private UserVo getUserVo(User userInfo) {
        System.out.println();
        UserVo userVo = new UserVo();
        userVo.setId(userInfo.getId());
        userVo.setAge(userInfo.getAge());
        userVo.setEmail(userInfo.getEmail());
        userVo.setPhone(userInfo.getPhone());
        userVo.setRealName(userInfo.getRealName());
        userVo.setSex(userInfo.getSex());
        userVo.setUserName(userInfo.getUserName());
        userVo.setPay(userInfo.getPay());
        userVo.setEntryTime(DateUtil.date2str(userInfo.getEntryTime(),DateUtil.Y_M_D));
        userVo.setHeadImagePath(userInfo.getHeadImagePath());
        userVo.setSalt(userInfo.getSalt());
        return userVo;
    }

    /**
     * 修改页面
     * @param
     * @return
     */
    @Override
    public UserVo toUpdateUser(Integer id) {
        User user = userMapper.toUpdateUser(id);
        //查询这个用户的所有角色
        System.out.println(1);
        Integer[] roleIdArray = userMapper.toUpdateRoleById(id);
        UserVo userVo = getUserVo(user);
        userVo.setRoleIds(roleIdArray);
        userVo.setPassword(user.getPassword());
        return userVo;
    }

    /**
     * 修改用户数据的方法
     * @param
     */
    @Override
    public void updateUser(User user) {
        //修改的时候加密
        if(StringUtils.isNotEmpty(user.getPassword())){
            user.setPassword(Md5Util.md5(Md5Util.md5(user.getPassword())+user.getSalt()));
        }
        userMapper.updateUser(user);
        //删除当前用户的所有角色
        System.out.println(1);
        userMapper.deleteRoleByUserId(user.getId());
        //重新保存当前用户的角色数据
        Integer[] roleIds = user.getRoleIds();
        if(roleIds!=null && roleIds.length>0){
            addUserRoleById(user, roleIds);
        }
    }

    /**
     * 这是删除单条数据的方法
     * @param id
     */
    @Override
    public void deleteUser(Integer id) {
        //根据id查询用户的图片名称
        User user = userMapper.toUpdateUser(id);
        //删除此用户对应的用户角色中间表的数据
        userMapper.deleteRoleByUserId(Long.valueOf(id));
        //删除此用户对应的头像
        if(StringUtils.isNotEmpty(user.getHeadImagePath())){
            FileUtil.deleteFtpFile(user.getHeadImagePath());
        }
        //删除用户
        userMapper.deleteUser(id);
    }

    /**
     * 批量删除
     * @param ids
     */
    @Override
    public void deleteUserByIds(Integer[] ids) {
        //删除用户
        userMapper.deleteUserByIds(ids);
        //删除用户对应的用户角色中间表数据
        userMapper.deleteRoleByIds(ids);
    }

    /**
     * 图片上传
     * @param myfile
     * @return
     */
    @Override
    public Map uploadFile(MultipartFile myfile) {
        Map map = FileUtil.addFile(myfile);
        return map;
    }

    @Override
    public User login(User user) {
        return userMapper.login(user);
    }

    @Override
    public void updateUserTime(User userInfo) {
        userMapper.updateUserTime(userInfo);
    }

    @Override
    public void updateUserLoginCount(User userInfo) {
        userMapper.updateUserLoginCount(userInfo);
    }

    /**
     * 查询导出的数据
     * @param userSearchParam
     * @return
     */
    @Override
    public List<UserVo> findUser(UserSearchParam userSearchParam){
        //查询数据
        List<User> userList = userMapper.userListExport(userSearchParam);
        //po转换vo用于展示
        List<UserVo> userVoList = buildUserVo(userList);
        return userVoList;
    }

    @Override
    public void exportPdf(UserSearchParam userSearchParam, HttpServletResponse response) throws IOException, DocumentException {
        if(userSearchParam.getRoleIds()!=null){
            userSearchParam.setRoleIdsLengTh(userSearchParam.getRoleIds().length);
        }
        //条件查询数据源
        List<UserVo> userList = findUser(userSearchParam);
        // 定义一个字节数组
        ByteArrayOutputStream byffer = new ByteArrayOutputStream();
        Font keyfont = FileUtil.keyFont();
        // 创建文本对象
        Document document = new Document(PageSize.A4);
        //pdf书写器
        PdfWriter.getInstance(document, byffer);
        //打开文档
        document.open();
        //表头
        String[] head = {"用户名", "真实姓名", "性别", "年龄", "电话", "邮箱", "薪资", "入职时间", "角色","头像"};
        //创建表格
        PdfPTable table = FileUtil.createTable(head.length);
        Font headfont = FileUtil.headFont();
        // 设置颜色
        headfont.setColor(BaseColor.RED);
        // 设置PDF表格标题
        PdfPCell cellTou = FileUtil.createHeadline("用户资料", headfont);
        // 设置段落之间的距离
        cellTou.setExtraParagraphSpace(20);
        table.addCell(cellTou);
        // 将表头添加到pdf文件中
        for (int i = 0; i < head.length; i++) {
            table.addCell(FileUtil.createCell(head[i], keyfont, Element.ALIGN_CENTER));
        }
        // 添加内容到pdf文件中
        for (int i = 0; i < userList.size(); i++) {
            table.addCell(FileUtil.createCell(userList.get(i).getUserName(), keyfont, Element.ALIGN_CENTER));
            table.addCell(FileUtil.createCell(userList.get(i).getRealName(), keyfont, Element.ALIGN_CENTER));
            table.addCell(FileUtil.createCell((userList.get(i).getSex() == 1 ? "男" : userList.get(i).getSex() == 0 ? "女" : "未知"), keyfont, Element.ALIGN_CENTER));
            table.addCell(FileUtil.createCell(userList.get(i).getAge().toString(), keyfont, Element.ALIGN_CENTER));
            table.addCell(FileUtil.createCell(userList.get(i).getPhone(), keyfont, Element.ALIGN_CENTER));
            table.addCell(FileUtil.createCell(userList.get(i).getEmail(), keyfont, Element.ALIGN_CENTER));
            table.addCell(FileUtil.createCell(userList.get(i).getPay().toString(), keyfont, Element.ALIGN_CENTER));
            table.addCell(FileUtil.createCell(userList.get(i).getEntryTime(), keyfont, Element.ALIGN_CENTER));
            table.addCell(FileUtil.createCell(userList.get(i).getRoleNames(), keyfont, Element.ALIGN_CENTER));
            //判断当前用户是否有头像
            if(StringUtils.isNotEmpty(userList.get(i).getHeadImagePath())){
                FileUtil.ftpDownload(userList.get(i).getHeadImagePath());
                Image  img = Image.getInstance("D:/upload/"+userList.get(i).getHeadImagePath());
                table.addCell(img);
            }else{
                table.addCell(FileUtil.createCell("没有头像",keyfont,Element.ALIGN_CENTER));
            }
        }
        document.add(table);
        document.close();
        FileUtil.pdfDownload(response, byffer);
        //下载完成后删除本地图片
        for (UserVo userVo : userList) {
            File file = new File("D:/upload/"+userVo.getHeadImagePath());
            file.delete();
        }
    }

    @Override
    public void exportExcel(UserSearchParam userSearchParam, HttpServletResponse response) {
        if(userSearchParam.getRoleIds()!=null){
            userSearchParam.setRoleIdsLengTh(userSearchParam.getRoleIds().length);
        }
        //条件查询数据源
        List<UserVo> userList = findUser(userSearchParam);
        //转换为workbook
        XSSFWorkbook xsf = buildWorkBook(userList);
        //下载
        FileUtil.excelDownload(xsf, response);
    }

    private XSSFWorkbook buildWorkBook(List<UserVo> userList) {
        XSSFWorkbook xsf = new XSSFWorkbook();
        //创建一个sheet
        XSSFSheet sheet = xsf.createSheet();
        //创建标题
        buildTitle(sheet,xsf);
        // 创建第一行  构造表头
        buildHeadRow(sheet);
        //将查询到的数据输入到文档中
        buildBody(userList, sheet);
        return xsf;
    }

    private void buildTitle(XSSFSheet sheet,XSSFWorkbook xsf) {
        XSSFCellStyle cellStyle = buildTitleStyle(xsf);
        XSSFRow row = sheet.createRow(3);
        XSSFCell cell = row.createCell(7);
        cell.setCellValue("用户列表");
        //第四行到第六行   第8个单元格到第10个单元格
        CellRangeAddress cellRangeAddress = new CellRangeAddress(3, 5, 7, 9);
        sheet.addMergedRegion(cellRangeAddress);
        cell.setCellStyle(cellStyle);
    }

    private XSSFCellStyle buildTitleStyle(XSSFWorkbook xsf) {
        XSSFCellStyle cellStyle = xsf.createCellStyle();
        //水平居中
        cellStyle.setAlignment(CellStyle.ALIGN_CENTER);
        //垂直居中
        cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        return cellStyle;
    }

    private void buildBody(List<UserVo> userList, XSSFSheet sheet) {
        for (int i = 0; i < userList.size(); i++) {
            //从第二行开始创建
            XSSFRow rowTo = sheet.createRow(i + 7);
            rowTo.createCell(7).setCellValue(userList.get(i).getUserName());
            rowTo.createCell(8).setCellValue(userList.get(i).getRealName());
            rowTo.createCell(9).setCellValue((userList.get(i).getSex() == 1 ? "男" : userList.get(i).getSex() == 0 ? "女" : "未知"));
            rowTo.createCell(10).setCellValue(userList.get(i).getAge());
            rowTo.createCell(11).setCellValue(userList.get(i).getPhone().toString());
            rowTo.createCell(12).setCellValue(userList.get(i).getEmail());
            rowTo.createCell(13).setCellValue(userList.get(i).getPay());
            rowTo.createCell(14).setCellValue(userList.get(i).getEntryTime());
            rowTo.createCell(15).setCellValue(userList.get(i).getRoleNames());
        }
    }

    private void buildHeadRow(XSSFSheet sheet) {
        //表头
        String[] head = {"用户名", "真实姓名", "性别", "年龄", "电话", "邮箱", "薪资", "入职时间", "角色"};
        XSSFRow row = sheet.createRow(6);
        for (int i = 0; i < head.length; i++) {
            row.createCell(i+7).setCellValue(head[i]);
        }
    }

    @Override
    public List<Wealth> findWealthByUserId(User user) {
        List<Wealth> wealthByUserId = wealthMapper.findWealthByUserId(user);
        return wealthByUserId;
    }
}
