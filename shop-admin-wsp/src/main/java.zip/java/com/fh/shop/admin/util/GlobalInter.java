package com.fh.shop.admin.util;

public class GlobalInter {
    //linux系统ip地址
    public static final String IP_FTP = "192.168.124.76";
    //ftp客户端用户名
    public static final String FTP_USERNAME = "ftpwsp";
    //ftp客户端用户密码
    public static final String FTP_USERPWD = "123";
    //上传ftp服务器下的文件夹路径
    public static final String FTP_PATH ="Public";
}
